<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>login successfully</title>

    <link rel="stylesheet" type="text/css" href="loginbackground.css">
  </head>
  <body>
    <header>
    <div id="particles-js" class="container" class="main">
      <div class="title">
      <h1>LOGIN SUCCESSFULLY</h1>
    </div>

      <ul>
        <li><a href="index.html">Home</a></li>
        <li><a href="#">Services</a></li>
        <li><a href="https://www.google.com/search?q=covid&rlz=1C1RLNS_enIN805IN805&sxsrf=ALeKk03WdHsiG1eWwQ8rtZIZRqF_dZlv8A:1594878547900&source=lnms&tbm=isch&sa=X&ved=2ahUKEwi-vrrKidHqAhUH4HMBHfyOBwwQ_AUoAnoECCMQBA&biw=1536&bih=731" target="_blank">Gallery</a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
    </div>
    </header>
    <script type="text/javascript" src="particles.js"></script>
    <script type="text/javascript" src="app.js"></script>
  </body>
</html>
